﻿param($ResourceGroupName, $APIMInstanceName, $SubscriptionId, $AADGroupName, $APIMServiceCustomRoleReader)


#Define Scope & Role variables
$APIMScope = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.ApiManagement/service/$APIMInstanceName"

$APIMServiceCustomRoleReader

<#
################################################################################################
#Get User profile & Assign Roles at user level
################################################################################################

$AADUserInfo = Get-AzADUser -Mail "$AADUserName"
$AADUserId = $AADUserInfo.Id
$AADUserId

Write-Host "*************Check existing roles for $AADUserName***********"

$Allroles = Get-AzRoleAssignment -ObjectId "$AADUserId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

Write-Host "*************Assigning new roles to $AADUserName***********"
## Assign APIM reader role at API Management level directly
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope"
    New-AzRoleAssignment -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleReader is assigned over scope $APIMScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}


#to check level of access for a user on API Management use below powershell - custom roles will not be visible on the portal
Write-Host "*************New roles for $AADUserName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADUserId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}
#>


################################################################################################
#Get Group profile & Assign Roles at group level
################################################################################################

## Fetch Group details

$AADGroupInfo = Get-AzADGroup -DisplayName "$AADGroupName" -ErrorAction Stop
$AADGroupId = $AADGroupInfo.Id
$AADGroupId 


Write-Host "*************Check existing roles for $AADGroupName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADGroupId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

Write-Host "*************Assigning new roles to $AADGroupName***********"
## Assign APIM reader role at API Management level directly
try {
    Write-Host "New-AzRoleAssignment -ObjectId $AADGroupId -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope"
    New-AzRoleAssignment -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleReader is assigned over scope $APIMScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}


#to check level of access for a user on API Management use below powershell - custom roles will not be visible on the portal
Write-Host "*************New roles for $AADGroupName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADGroupId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

