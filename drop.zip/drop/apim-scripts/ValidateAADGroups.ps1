﻿param($RepositoryPath, $envFlag)


$configJson = "$RepositoryPath\config.json"
$jobj = Get-Content -Path $configJson | Out-String | ConvertFrom-Json

<#
## Fetch User details
if ($envFlag -eq "Prod"){
    $AADUserName = $jobj.Prod.AAD_User_Name
    $AADUserName
}
else{
    $AADUserName = $jobj.Dev.AAD_User_Name
    $AADUserName
}

## VAlidate AAD User
try {
    $AADGroupInfo = $AADUserInfo = Get-AzADUser -Mail "$AADUserName"
    if($AADGroupInfo -eq $null) {
        Write-Host "$AADUserName is not a valid AAD User" -ForegroundColor Red
        Write-Host "##vso[task.complete result=Failed;]DONE"
    } else {
        $AADUserId = $AADUserInfo.Id
        $AADUserId
    }
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}
#>

## Fetch Group details
if ($envFlag -eq "Prod"){
    $AADGroupName = $jobj.Prod.AAD_Group_Name
    $AADGroupName
}
else{
    $AADGroupName = $jobj.Dev.AAD_Group_Name
    $AADGroupName
}

## VAlidate AAD group
try {
    $AADGroupInfo = Get-AzADGroup -DisplayName "$AADGroupName"
    if($AADGroupInfo -eq $null) {
        Write-Host "$AADGroupName is not a valid AAD group" -ForegroundColor Red
        Write-Host "##vso[task.complete result=Failed;]DONE"
    } else {
        $AADGroupId = $AADGroupInfo.Id
        $AADGroupId
    }
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}
