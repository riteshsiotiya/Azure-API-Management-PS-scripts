﻿param($ResourceGroupName, $APIMInstanceName, $SubscriptionId, $RepositoryPath,$APIName, $ProductName, $APIMServiceCustomRoleReader, $APIMServiceCustomRoleContributor, $envFlag)


#Define Scope & Role variables
$APIMScope = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName/providers/Microsoft.ApiManagement/service/$APIMInstanceName"
$ProductScope = "$APIMScope/products/$ProductName"
$APIScope = "$APIMScope/apis/$APIName"
$APIMServiceCustomRoleReader
$APIMServiceCustomRoleContributor

$configJson = "$RepositoryPath\config.json"
$jobj = Get-Content -Path $configJson | Out-String | ConvertFrom-Json


################################################################################################
#Get User profile & Assign Roles at user level
################################################################################################
<#
## Fetch User details
if ($envFlag -eq "Prod"){
    $AADUserName = $jobj.Prod.AAD_User_Name
    $AADUserName
}
else{
    $AADUserName = $jobj.Dev.AAD_User_Name
    $AADUserName
}

$AADUserInfo = Get-AzADUser -Mail "$AADUserName"
$AADUserId = $AADUserInfo.Id
$AADUserId

Write-Host "*************Check existing roles for $AADUserName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADUserId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

Write-Host "*************Assigning new roles to $AADUserName***********"
## Assign APIM reader role at API Management level directly
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope"
    New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleReader is assigned over scope $APIMScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}


## Assign APIM contributor role at Product scope level
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope"
    New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleContributor is assigned over scope $ProductScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n    
}

## Assign APIM contributor role at API scope level
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope"
    New-AzRoleAssignment  -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleContributor is assigned over scope $APIScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}

#to check level of access for a user on API Management use below powershell - custom roles will not be visible on the portal
Write-Host "*************New roles for $AADUserName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADUserId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}
#>
#Remove user access
<#
Remove-AzRoleAssignment -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope

Remove-AzRoleAssignment -ObjectId "$AADUserId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope

Remove-AzRoleAssignment -ObjectId $AADUserId -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope
#>


################################################################################################
#Get Group profile & Assign Roles at group level
################################################################################################

## Fetch Group details
if ($envFlag -eq "Prod"){
    $AADGroupName = $jobj.Prod.AAD_Group_Name
    $AADGroupName
}
else{
    $AADGroupName = $jobj.Dev.AAD_Group_Name
    $AADGroupName
}

$AADGroupInfo = Get-AzADGroup -DisplayName "$AADGroupName"
$AADGroupId = $AADGroupInfo.Id
$AADGroupId 

Write-Host "*************Check existing roles for $AADGroupName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADGroupId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

Write-Host "*************Assigning new roles to $AADGroupName***********"
## Assign APIM reader role at API Management level directly
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope"
    New-AzRoleAssignment  -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleReader is assigned over scope $APIMScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}


## Assign APIM contributor role at Product scope level
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope"
    New-AzRoleAssignment  -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleContributor is assigned over scope $ProductScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n    
}

## Assign APIM contributor role at API scope level
try {
    Write-Host "New-AzRoleAssignment  -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope"
    New-AzRoleAssignment  -ObjectId "$AADGroupId"-RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope -ErrorAction Stop
    Write-Host "Role $APIMServiceCustomRoleContributor is assigned over scope $APIScope `n"
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Host $ErrorMessage `n
}

#to check level of access for a user on API Management use below powershell - custom roles will not be visible on the portal
Write-Host "*************New roles for $AADGroupName***********"
$Allroles = Get-AzRoleAssignment -ObjectId "$AADGroupId"
foreach ($role in $Allroles){
    Write-Host "Role: "$role.RoleDefinitionName
    Write-Host "Scope: "$role.Scope `n
}

#Remove group access
<#
Remove-AzRoleAssignment -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleReader -Scope $APIMScope

Remove-AzRoleAssignment -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $ProductScope

Remove-AzRoleAssignment -ObjectId "$AADGroupId" -RoleDefinitionName $APIMServiceCustomRoleContributor -Scope $APIScope

#>
