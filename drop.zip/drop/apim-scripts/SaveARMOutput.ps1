﻿param($armOutput)
$var=ConvertFrom-Json "$armOutput"

$APINameValue = $var.APIName.value
$APINameValue = $APINameValue.ToLower()
Write-Host "API Name: $APINameValue"
Write-Host "##vso[task.setvariable variable=APIName;]$APINameValue"

$APISuffixValue  = $var.ApiSuffix.value
$APISuffixValue = $APISuffixValue.ToLower()
Write-Host "API Suffix: $APISuffixValue"
Write-Host "##vso[task.setvariable variable=APISuffix;]$APISuffixValue"

$ProductNameValue = $var.ProductName.value
Write-Host "Product Name: $ProductNameValue"
Write-Host "##vso[task.setvariable variable=ProductName;]$ProductNameValue"

$ServiceUrlValue=$var.ServiceUrl.value
Write-Host "Service URL: $ServiceUrlValue"
Write-Host "##vso[task.setvariable variable=ServiceURL;]$ServiceUrlValue"
