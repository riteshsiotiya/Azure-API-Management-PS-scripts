﻿param($ResourceGroupName, $APIMInstanceName, $RepositoryPath,$APIName, $ApiURLsuffix, $ApiServiceURL, $envFlag)


Write-Host "Creating APIM Context"
Write-Host "New-AzApiManagementContext -ResourceGroupName $resourceGroupName -ServiceName $APIMInstanceName"
$ApiMgmtContext = New-AzApiManagementContext -ResourceGroupName $resourceGroupName -ServiceName $APIMInstanceName

$strSwaggerDir = "$RepositoryPath\swagger"
Write-Host "Swagger file directory : $strSwaggerDir"
$swaggerFiles = Get-ChildItem $strSwaggerDir -Filter "*-$envFlag.json" -Force

#Import API operations from respective environment's swagger file
foreach($strSwagger in $swaggerFiles)
{
    $strSwaggerFile = $strSwagger.FullName
    Write-Host $strSwaggerFile

    Write-Host "Importing API operations from swagger file"
    Write-Host "Import-AzApiManagementApi -Context $ApiMgmtContext -ApiId $APIName -SpecificationFormat OpenApi -SpecificationPath $strSwaggerFile -Path $ApiURLsuffix -ServiceUrl $ApiServiceURL"
    Import-AzApiManagementApi -Context $ApiMgmtContext -ApiId "$APIName" -SpecificationFormat "OpenApi" -SpecificationPath "$strSwaggerFile" -Path "$ApiURLsuffix" -ServiceUrl "$ApiServiceURL"
    Write-Host "API operations imported successfully from swagger file"
}


# Update the API level policies for respective environment
$strPolicyDir = "$RepositoryPath\policies"
Write-Host "Policy file directory : $strPolicyDir"
$PolicyFiles = Get-ChildItem $strPolicyDir -Filter "*.$envFlag.xml" -Force
foreach($strPolicyFileName in $PolicyFiles)
{
    $strPolicyName = $strPolicyFileName.Name
    $strPolicyFilePath = $strPolicyFileName.FullName

    if($strPolicyName -match "operationPolicy")
    {
        ## Code to set Operation scope policy here

        Write-Host $strPolicyFilePath

        $strOperationName = $strPolicyName -split ".operationPolicy.$envFlag.xml"
        Write-Host "Operation Name: $strOperationName"

        $apiOperations = Get-AzApiManagementOperation -Context $ApiMgmtContext -ApiId $APIName

        foreach($operation in $apiOperations)
        {
            $strOperationId = $operation.OperationId
                        
            if($strOperationName -eq $strOperationId)
            {
                Write-Host "Operation ID: $strOperationId"
                Write-Host "Setting Operation scope policies for $strOperationId"
                Write-Host "Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $APIName -OperationId $strOperationId -PolicyFilePath $strPolicyFilePath -Format RawXml"
                Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId "$APIName" -OperationId $strOperationId -PolicyFilePath "$strPolicyFilePath" -Format RawXml
 
                Write-Host "API Operation scope policies set successfully for $strOperationId"
            }
        }
    }
    if($strPolicyName -match "apiPolicy")
    {
        ## Code to set API scope policy here
                
        Write-Host $strPolicyFilePath

        Write-Host "API Name: $APIName"

        Write-Host "Setting API scope policies for $APIName"
        Write-Host "Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId $APIName -PolicyFilePath $strPolicyFilePath -Format RawXml"
        Set-AzApiManagementPolicy -Context $ApiMgmtContext -ApiId "$APIName" -PolicyFilePath "$strPolicyFilePath" -Format RawXml
 
        Write-Host "API scope policies set successfully for $APIName"
    }
}