param($DisplayName, $APIsuffix, $version, $env)

$APIDisplayName = "$DisplayName"
$APIId = "$DisplayName".ToLower()
$ApiURLsuffix = "$APIsuffix".ToLower()


if ($env -ne "prod")
{
    $APIDisplayName = "$DisplayName-$env"
    $APIId = "$DisplayName-$env".ToLower()
    $ApiURLsuffix = "$APIsuffix-$env".ToLower()
}

if($version -ne ""){
    $ApiURLsuffix = "$ApiURLsuffix/$version"
}

$APIDisplayName
$APIId
$ApiURLsuffix

Write-Host "##vso[task.setvariable variable=APIDisplayName]$APIDisplayName"
Write-Host "##vso[task.setvariable variable=APIName]$APIId"
Write-Host "##vso[task.setvariable variable=Apisuffix]$ApiURLsuffix"