# Introduction 
This repository is used to store the source files for the ARM deployment process of APIs on HSB's API Management services. hsbapidev for non-prod and hsbapi for prod environments.

# Content

## /azuredeploy.json
 This is the main ARM template. Currently it defines parameters, contains the definition of API version sets, APIs and Products. Normally you won't have to change this file, but don't forget to update this file if you add/remove ARM parameters or if you change the proposed template structure altogether. You can modify this file to support deployment of Group and multiple APIs.

 ## /azuredeploy.parameters.{environmentName}.json
 There should be one **azuredeploy.parameters.{environmentName}.json** files for each environment. They contain the ARM parameters for each of the project's defined environments. The parameters from the following table might differ from your implementation, but the validation rules must be met by all.
 
| Parameter | Description |
|--|--|
| ApiManagementInstanceName | This parameter is set automatically by the pipeline. Don't remove or provide a value. |
| ProductName | Sets the name of the product. Don’t Update will be changed by pipeline |
| ApiDisplayName | Sets the name of the Display API. Don’t Update will be changed by pipeline |
| ApiName | Sets the name (Id)of the API. Don’t Update will be changed by pipeline |
| ServiceUrl | Sets the backend Service URL for the API. Don’t Update will be changed by pipeline |
| ApiSuffix | Sets the path of the API or APIurlSuffix. Don’t Update will be changed by pipeline |

**Key NOTES To Follow in API Naming Conventions:**
- User to provide API Name & ApiSuffix in pipeline variables.
-	The names should be as per the names required in Production, for lower environment a suffix with env identifier will be appended.
-	API Name can be in Caps or lowercase but API Suffix must be in lowercase
- **No Spaces** allowed in API Name or API Suffix
  - $APIDisplayName - Can be in Caps or lower case, No spaces
  - $APIId - Should be in lower case, will be generated automatically using API name
  - $ApiURLsuffix - Should be in lower case, will be generated automatically using API suffix
  
for e.g.
If user provide API Name = "MyProject-API" and suffix as "proj-api"
Then, the above values will be used for production APIs but for lower environments the values will be auto generated and will be,

for DEV

  -	$APIDisplayName - "MyProject-API-Dev"
  -	$APIId - "myproject-api-dev"
  -	$ApiURLsuffix - "proj-api-dev"

## /config.json
The **config.json** file contains the AAD Group name for Dev (non-Prod) & Prod environment. The Group will get contributor access on respective APIs in non-prod environment and Reader access on Prod environment.

## /swagger
Folder containing the swagger file(s) to be published on the API Management service. You can define multiple APIs with versions and/or revisions in your ARM templates, therefore you may have multiple swagger files. The swagger files is created with openapi 3.0.1 specification and should comply with the following rules:
 - **File name** must follow the **{apiName}-{environmentName}.json** format.
 - The **{apiName}** in the Swagger file name **must match the API name specified in the ARM template**.
 - The **{environmentName}** in the Swagger file name **must match an environment names viz. Dev, QA, Stage, Prod**.
 - The **info.title** property inside the Swagger file **must match the API name specified in the ARM template** except for Prod swagger where you need to have swagger file name as **{apiName}-Prod.json** and info.title as **{apiName}**.
 - Optionally, you may use **revisions**. In this case, the Swagger file name format to follow becomes **{apiName}.{revisionName}.{environmentName}.json**. In case you do not specify a revision, the Swagger file is imported to the currently active revision.
 - **IMPORTANT**: some API attributes can be set both in the ARM template and the Swagger files. 
 
 **NOTE: APIM is designed to override values from the ARM templates with values from the Swagger files. To avoid this, we have removed service url and api suffix from swagger and passing it to the ARM template through pipeline.**

## /policies
Folder containing the policy file(s) to be published on the API Management service for respective APIs or Operations. You can define multiple policies for respective operations, therefore you may have multiple policy files.
 - **File name**  for **API Policy** must follow the **{apiPolicy}.{environmentName}.xml** format.
 - **File name**  for **Operation Policies** must follow the **{operationName}.{operationPolicy}.{environmentName}.xml** format.
 - The **{operationName}** in the policy file name **must match the operation Id specified in the swagger**.
 - The **{environmentName}** in the policy file name **must match an environment names viz. Dev, QA, Stage**.

## /Import-APIOperationsandPolicies.ps1
This is a powershell script used to import the API operations from respective swagger files and policies from respective policy xml files based on specific environment. This is an paramaterised script and the parameters are passed though pipeline, below table describe various parameters required in it.

| Parameter | Description |
|--|--|
| $ResourceGroupName | Name of Azure resource group where APIM instance is present. Non-Prod: HB-API-D01, Prod: HB-API-P01|
| $ApiManagementInstanceName | Name of Azure APIM instance. Non-Prod: hsbapidev, Prod: hsbapi|
| $ApiName | Name of the API. |
| $ServiceUrl | Name of the backend Service URL for the API. |
| $ApiSuffix | Name of the path of the sample API or APIurlSuffix. |
| $RepositoryPath | Base location of a folder where template files are downloaded. |
| $envFlag | Flag to set env viz. Dev, QA, Stage |

# Getting Started
- Duplicate the **azuredeploy.parameters.{environmentName}.json** ARM Template Parameter files as needed for your environments, replace the environment name in the file name and fill in the required parameters (## FILL IN ##).
- Fill in the required fields (## FILL IN ##) in all **/templates/*.json** nested templates.
- Provide the **Swagger definitions**:
  - Place and correctly name your Swagger file(s) in the /swagger folder considering the **{apiName}.{environmentName}.json** pattern and the rules detailed above.
  - Replace the required parameters (## FILL IN ##) with your own considering the rules detailed above.
  - Replace the rest of the file(s) content with your own Swagger specification.
- Uncomment the policies in /policies/apiPolicy.json as per your VAPT and other requirements.